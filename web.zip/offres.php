<?php
echo "test" ;
class offres{
    public string $nom;
    public string $prenom;
    public string $email;
    public string $code_promo;
    public string $plats;
    public string $prix;
    public string $remise;
}
public function saisir(string $nom,string $prenom,string $email,string $code_promo, string $plats,string $prix,string $remise) {
    $this->nom=$nom;
    $this->prenom=$prenom;
    $this->email=$email;
    $this->code_promo=$code_promo;
    $this->plats=$plats;
    $this->prix=$prix;
    $this->remise=$remise;
    public function afficher()
        {
            echo "<table border=7>";
            echo "<tr>";
            echo"<td > nom : </td>";
            echo "<td colspan> prenom : </td>" ;
            echo "<td colspan> email : </td>";
            echo  "<td colspan>code_promo</td>";
            echo "<td colspan> plats : </td>";
            echo "<td colspan> prix : </td>";
            echo "<td colspan> remise : </td>";
            echo "</tr>";
            echo"<tr>";
            echo"<td> $this->nom </td>";
            echo"<td>  $this->prenom </td>";
            echo "<td>  $this->email </td> ";
            echo "<td>  $this->code_promo </td> ";
            echo "<td>  $this->plats </td> ";
            echo "<td>  $this->prix </td> ";
            echo "<td>  $this->remise </td> ";
            echo "</tr>";
            echo "</table>";
          
        }  
        
    }
    $user1=new offres($_POST['nom '],$_POST['prenom'],$_POST['mail'],$_POST['code_promo'],$_POST['plats'],$_POST['prix'],$_POST['remise']);
    var_dump($user1);
    $user1->afficher();
?>