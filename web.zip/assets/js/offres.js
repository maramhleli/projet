let fNameInput = document.getElementById("nom");
let lNameInput = document.getElementById("prenom");
let phoneInput = document.getElementById("email");
let passInput = document.getElementById("code_promo");


function passValidation() {
    if (
        passInput.value != cPassInput.value ||
        passInput.value == "" ||
        cPassInput == ""
    ) {
        alert("Le code n'est pas correctes!!!");

        return false;
    } else {
        alert(" OK");
    }
}

function nameValidation() {
    if (lNameInput.value.length < 3) {
        lNameError = " Le nom doit compter au minimum 3 caractères.";
        document.getElementById("nom").innerHTML = lNameError;

        return false;
    }
    if (!lNameInput.value.match(letters)) {
        lNameError2 = "Veuillez entrer un nom valid ! (seulement des lettres)";
        lNameValid2 = false;
        document.getElementById("nom").innerHTML = lNameError2;
        return false;
    }
    document.getElementById("nom").innerHTML =
        "<p style='color:white'> Correct </p>";

    return true;
}

document.forms["inscription"].addEventListener("submit", function (e) {
    var inputs = document.forms["inscription"];
    let ids = [
        "erreur",
        "nom",
        "prenom",
        "Email",
        "code_promo",
        
    ];

    ids.map((id) => (document.getElementById(id).innerHTML = "")); // reinitialiser l'affichage des erreurs

    let errors = false;

    //Traitement cas par cas
    if (lNameInput.value.length < 3) {
        errors = false;
        document.getElementById("nom").innerHTML =
            "Le nom doit compter au minimum 3 caractères.";
    } else if (!lNameInput.value.match(letters)) {
        errors = false;
        document.getElementById("nom").innerHTML =
            "Veuillez entrer un nom valid ! (seulement des lettres)";
    } else {
        errors = true;
    }
    if (fNameInput.value.length < 4) {
        errors = false;
        document.getElementById("prenom").innerHTML =
            "Le prénom doit compter au minimum 4 caractères";
    } else {
        errors = true;
    }

 

    //Traitement générique
    for (var i = 0; i < inputs.length; i++) {
        if (!inputs[i].value) {
            errors = false;
            document.getElementById("erreur").innerHTML =
                "Veuillez renseigner tous les champs";
        }
    }

    if (errors === false) {
        e.preventDefault();
    } else {
        alert("formulaire envoyé");
    }
});